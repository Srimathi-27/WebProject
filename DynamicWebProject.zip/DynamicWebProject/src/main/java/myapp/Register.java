package myapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.*;

public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Register() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.setContentType("text/html");
	    PrintWriter out = response.getWriter();

	    String uidStr = request.getParameter("uid");
	    String uname = request.getParameter("uname");
	    String uageStr = request.getParameter("uage");
	    String usalaryStr = request.getParameter("usalary");
	    String udesig = request.getParameter("udesig");

	    if (uidStr == null || uname == null || uageStr == null || usalaryStr == null || udesig == null) {
	        out.println("<p style='color:red; text-align:center;'>Missing parameters</p>");
	        out.println("<a href='Register.html' style='display:block; text-align:center;'>Back to Register</a>");
	        return;
	    }

	    try {
	        int uid = Integer.parseInt(uidStr);
	        int uage = Integer.parseInt(uageStr);
	        int usalary = Integer.parseInt(usalaryStr);

	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hexaware", "root", "12345");

	        PreparedStatement pstmt = con.prepareStatement("INSERT INTO employees VALUES (?, ?, ?, ?, ?)");
	        pstmt.setInt(1, uid);
	        pstmt.setString(2, uname);
	        pstmt.setInt(3, uage);
	        pstmt.setInt(4, usalary);
	        pstmt.setString(5, udesig);

	        int rows = pstmt.executeUpdate();
	        pstmt.close();
	        con.close();

	        if (rows > 0) {
	            out.println("<p style='color:green; text-align:center;'>User " + uname + " registered successfully!</p>");
	        } else {
	            out.println("<p style='color:red; text-align:center;'>Failed to register user.</p>");
	        }

	    } catch (NumberFormatException e) {
	        out.println("<p style='color:red; text-align:center;'>Invalid number format.</p>");
	    } catch (SQLException e) {
	        out.println("<p style='color:red; text-align:center;'>Database error: " + e.getMessage() + "</p>");
	    } catch (ClassNotFoundException e) {
	        out.println("<p style='color:red; text-align:center;'>JDBC Driver not found.</p>");
	    }

	    out.println("<p style='text-align:center;'><a href='List.html'>Back to Home</a></p>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    doGet(request, response);
	}
}
