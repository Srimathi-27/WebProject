package myapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public LoginPage() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("uname");
		String pass = request.getParameter("upass");

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		if ("Vijaya".equalsIgnoreCase(name) && "Vijaya@123".equals(pass)) {
			RequestDispatcher rd = request.getRequestDispatcher("List.html");
			rd.forward(request, response);
		} else {
			out.println("<p style='color:red; text-align:center;'>Invalid Username or Password</p>");
			RequestDispatcher rd = request.getRequestDispatcher("Login.html");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
