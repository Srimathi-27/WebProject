package myapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.*;

public class UpdatePage extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public UpdatePage() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.setContentType("text/html");
	    PrintWriter out = response.getWriter();

	    String uidStr = request.getParameter("uid");
	    String usalaryStr = request.getParameter("usalary");

	    if (uidStr == null || usalaryStr == null) {
	        out.println("<p style='color:red; text-align:center;'>Missing parameters</p>");
	        out.println("<a href='Update.html' style='display:block; text-align:center;'>Back to Update</a>");
	        return;
	    }

	    try {
	        int uid = Integer.parseInt(uidStr);
	        int usalary = Integer.parseInt(usalaryStr);

	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hexaware", "root", "12345");

	        PreparedStatement pstmt = con.prepareStatement("UPDATE employees SET usalary=? WHERE uid=?");
	        pstmt.setInt(1, usalary);
	        pstmt.setInt(2, uid);

	        int rows = pstmt.executeUpdate();
	        pstmt.close();
	        con.close();

	        if (rows > 0) {
	            out.println("<p style='color:green; text-align:center;'>User salary updated successfully!</p>");
	        } else {
	            out.println("<p style='color:red; text-align:center;'>User ID not found.</p>");
	        }

	    } catch (NumberFormatException e) {
	        out.println("<p style='color:red; text-align:center;'>Invalid number format.</p>");
	    } catch (SQLException e) {
	        out.println("<p style='color:red; text-align:center;'>Database error: " + e.getMessage() + "</p>");
	    } catch (ClassNotFoundException e) {
	        out.println("<p style='color:red; text-align:center;'>JDBC Driver not found.</p>");
	    }

	    out.println("<p style='text-align:center;'><a href='List.html'>Back to Home</a></p>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    doGet(request, response);
	}
}
