package myapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.*;

public class DeletePage extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DeletePage() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.setContentType("text/html");
	    PrintWriter out = response.getWriter();

	    String uidStr = request.getParameter("uid");

	    if (uidStr == null) {
	        out.println("<p style='color:red; text-align:center;'>Missing User ID</p>");
	        out.println("<a href='Delete.html' style='display:block; text-align:center;'>Back to Delete</a>");
	        return;
	    }

	    try {
	        int uid = Integer.parseInt(uidStr);

	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hexaware", "root", "12345");

	        PreparedStatement pstmt = con.prepareStatement("DELETE FROM employees WHERE uid=?");
	        pstmt.setInt(1, uid);

	        int rows = pstmt.executeUpdate();
	        pstmt.close();
	        con.close();

	        if (rows > 0) {
	            out.println("<p style='color:green; text-align:center;'>User deleted successfully!</p>");
	        } else {
	            out.println("<p style='color:red; text-align:center;'>User ID not found.</p>");
	        }

	    } catch (NumberFormatException e) {
	        out.println("<p style='color:red; text-align:center;'>Invalid number format.</p>");
	    } catch (SQLException e) {
	        out.println("<p style='color:red; text-align:center;'>Database error: " + e.getMessage() + "</p>");
	    } catch (ClassNotFoundException e) {
	        out.println("<p style='color:red; text-align:center;'>JDBC Driver not found.</p>");
	    }

	    out.println("<p style='text-align:center;'><a href='List.html'>Back to Home</a></p>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    doGet(request, response);
	}
}
