package myapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class ReadPage extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Employee List</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; background: linear-gradient(to right, #74ebd5, #ACB6E5); margin: 0; padding: 20px; }");
        out.println("h1 { text-align: center; color: #333; }");
        out.println("table { margin: 20px auto; border-collapse: collapse; width: 80%; box-shadow: 0 2px 15px rgba(0,0,0,0.1); background: white; }");
        out.println("th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }");
        out.println("th { background-color: #6a11cb; color: white; }");
        out.println("tr:hover { background-color: #f1f1f1; }");
        out.println("a { display: block; width: 100px; margin: 20px auto; padding: 10px; background: #6a11cb; color: white; text-align: center; text-decoration: none; border-radius: 5px; }");
        out.println("a:hover { background: #553a99; }");
        out.println("</style>");
        out.println("</head><body>");

        out.println("<h1>Employee Details</h1>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hexaware", "root", "12345");

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM employees");

            out.println("<table>");
            out.println("<tr><th>UserId</th><th>UserName</th><th>Age</th><th>Salary</th><th>Designation</th></tr>");

            boolean hasData = false;
            while (rs.next()) {
                hasData = true;
                out.println("<tr>");
                out.println("<td>" + rs.getInt("uid") + "</td>");
                out.println("<td>" + rs.getString("uname") + "</td>");
                out.println("<td>" + rs.getInt("uage") + "</td>");
                out.println("<td>" + rs.getInt("usalary") + "</td>");
                out.println("<td>" + rs.getString("udesig") + "</td>");
                out.println("</tr>");
            }

            if (!hasData) {
                out.println("<tr><td colspan='5'>No Records Found</td></tr>");
            }
            out.println("</table>");

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            out.println("<p style='color:red; text-align:center;'>Error: " + e.getMessage() + "</p>");
        }

        out.println("<a href='List.html'>Back to List</a>");

        out.println("</body></html>");
    }
}
